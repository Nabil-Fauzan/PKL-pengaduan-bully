<?php $__env->startSection('title', 'Tambah Petugas/Admin Baru'); ?>
<?php $__env->startSection('page_title', 'Tambah Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        
        <div class="card card-primary card-outline mb-5">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-plus mr-1"></i>
                    Formulir Registrasi Akun Petugas Baru
                </h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('admin.petugas')); ?>" class="btn btn-default btn-sm">
                        <i class="fas fa-arrow-left mr-1"></i> Kembali
                    </a>
                </div>
            </div>
            
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="icon fas fa-ban mr-2"></i> <strong>Ada kesalahan pengisian:</strong>
                        <ul class="mb-0 mt-1 pl-3 text-sm">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.petugas.simpan')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Nama Lengkap -->
                    <div class="form-group">
                        <label for="nama" class="font-weight-bold">Nama Lengkap Petugas:</label>
                        <input type="text" name="nama" id="nama" value="<?php echo e(old('nama')); ?>" 
                            placeholder="Masukkan nama lengkap beserta gelar..." class="form-control" required>
                    </div>

                    <!-- Username -->
                    <div class="form-group mt-3">
                        <label for="username" class="font-weight-bold">Username Akun:</label>
                        <input type="text" name="username" id="username" value="<?php echo e(old('username')); ?>" 
                            placeholder="Masukkan username unik..." class="form-control" required>
                        <small class="form-text text-muted">Akan digunakan untuk login ke panel back-end.</small>
                    </div>

                    <!-- Email -->
                    <div class="form-group mt-3">
                        <label for="email" class="font-weight-bold">Alamat Email:</label>
                        <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" 
                            placeholder="Masukkan email aktif..." class="form-control" required>
                    </div>

                    <!-- Password -->
                    <div class="form-group mt-3">
                        <label for="password" class="font-weight-bold">Password Akun:</label>
                        <div class="input-group">
                            <input type="password" name="password" id="password" 
                                placeholder="Masukkan password akun baru..." class="form-control" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="togglePasswordBtn" style="cursor: pointer;">
                                    <i class="fas fa-eye" id="eyeIcon"></i>
                                </span>
                            </div>
                        </div>
                        <small class="form-text text-muted">Minimal 4 karakter.</small>
                    </div>

                    <!-- Role -->
                    <div class="form-group mt-3">
                        <label for="role" class="font-weight-bold">Hak Akses / Peran:</label>
                        <select name="role" id="role" class="form-control" required>
                            <option value="petugas" <?php echo e(old('role') === 'petugas' ? 'selected' : ''); ?>>Petugas BK (Bimbingan Konseling)</option>
                            <option value="admin" <?php echo e(old('role') === 'admin' ? 'selected' : ''); ?>>Administrator (Akses Penuh)</option>
                        </select>
                    </div>

                    <!-- Status -->
                    <div class="form-group mt-3">
                        <label for="status" class="font-weight-bold">Status Akun:</label>
                        <select name="status" id="status" class="form-control" required>
                            <option value="aktif" <?php echo e(old('status', 'aktif') === 'aktif' ? 'selected' : ''); ?>>Aktif (Dapat Login)</option>
                            <option value="nonaktif" <?php echo e(old('status') === 'nonaktif' ? 'selected' : ''); ?>>Nonaktif (Kunci Akses)</option>
                        </select>
                    </div>

                    <!-- Form Actions -->
                    <div class="mt-4 pt-3 border-top d-flex justify-content-end">
                        <a href="<?php echo e(route('admin.petugas')); ?>" class="btn btn-default mr-2">Batal</a>
                        <button type="submit" class="btn btn-primary font-weight-bold">
                            <i class="fas fa-save mr-1"></i> Simpan Data Petugas
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const toggleBtn = document.getElementById('togglePasswordBtn');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', function() {
                const passwordInput = document.getElementById('password');
                const eyeIcon = document.getElementById('eyeIcon');
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    eyeIcon.classList.remove('fa-eye');
                    eyeIcon.classList.add('fa-eye-slash');
                } else {
                    passwordInput.type = 'password';
                    eyeIcon.classList.remove('fa-eye-slash');
                    eyeIcon.classList.add('fa-eye');
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/admin/petugas/create.blade.php ENDPATH**/ ?>