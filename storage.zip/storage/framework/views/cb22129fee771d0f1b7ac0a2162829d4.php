<?php $__env->startSection('title', 'Data Siswa'); ?>
<?php $__env->startSection('page_title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">

        <!-- Action & Search Card -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <a href="<?php echo e(route('admin.siswa.tambah')); ?>" class="btn btn-primary btn-sm font-weight-bold">
                            <i class="fas fa-plus mr-1"></i> Tambah Siswa Baru
                        </a>
                    </div>
                    <div class="col-md-6">
                        <form action="<?php echo e(route('admin.siswa')); ?>" method="GET" class="float-md-right w-100" style="max-width: 350px;">
                            <div class="input-group input-group-sm">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                                    placeholder="Cari nama siswa atau NIS..." class="form-control">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary font-weight-bold">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <?php if(request()->filled('search')): ?>
                                        <a href="<?php echo e(route('admin.siswa')); ?>" class="btn btn-default" title="Reset Pencarian">
                                            <i class="fas fa-sync-alt"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php if(session('success_message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="icon fas fa-check mr-2"></i> <?php echo e(session('success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="icon fas fa-ban mr-2"></i> <?php echo e(session('error_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <!-- List Card -->
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-user-graduate mr-1"></i>
                    Daftar Akun Siswa
                </h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead>
                            <tr>
                                <th style="width: 60px;" class="text-center">No</th>
                                <th>Nama Lengkap</th>
                                <th>NIS</th>
                                <th>Kelas</th>
                                <th>Jurusan</th>
                                <th style="width: 150px;">Status Akun</th>
                                <th style="width: 220px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = ($data_siswa->currentPage() - 1) * $data_siswa->perPage() + 1;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center font-weight-bold"><?php echo e($no++); ?></td>
                                    <td class="font-weight-bold"><?php echo e($siswa->nama); ?></td>
                                    <td><?php echo e($siswa->nis); ?></td>
                                    <td><?php echo e($siswa->kelas); ?></td>
                                    <td><?php echo e($siswa->jurusan); ?></td>
                                    <td>
                                        <?php if($siswa->status === 'aktif'): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php elseif($siswa->status === 'lulus'): ?>
                                            <span class="badge bg-secondary">Lulus</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Pindah</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-inline-flex align-items-center gap-1">
                                            <a href="<?php echo e(route('admin.siswa.edit', $siswa->id_siswa)); ?>" class="btn btn-success btn-xs font-weight-bold mr-1">
                                                <i class="fas fa-edit mr-1"></i> Ubah
                                            </a>
                                            
                                            <form action="<?php echo e(route('admin.siswa.toggle', $siswa->id_siswa)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin mengubah status aktif akun siswa ini?');">
                                                <?php echo csrf_field(); ?>
                                                <?php if($siswa->status === 'aktif'): ?>
                                                    <button type="submit" class="btn btn-danger btn-xs font-weight-bold">
                                                        <i class="fas fa-ban mr-1"></i> Nonaktifkan
                                                    </button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn btn-primary btn-xs font-weight-bold">
                                                        <i class="fas fa-check mr-1"></i> Aktifkan
                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">Tidak ada data siswa ditemukan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if($data_siswa->hasPages()): ?>
                <div class="card-footer clearfix d-flex justify-content-end">
                    <?php echo e($data_siswa->links('pagination::bootstrap-4')); ?>

                </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>