<section id="kategori" class="section-py">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <span class="section-tag">KLASIFIKASI KASUS</span>
            <h2 class="section-title">Kenali Jenis Perundungan di Sekolah</h2>
            <p class="section-subtitle">Pilihlah kategori yang sesuai saat mengirimkan laporan pengaduan agar tim penanganan dapat mengambil tindakan yang tepat sasaran.</p>
        </div>

        <div class="row g-4">
            <!-- Card 1: Bullying Fisik -->
            <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                <div class="category-card h-100">
                    <div class="category-icon cat-danger">
                        <i class="fas fa-fist-raised"></i>
                    </div>
                    <span class="category-tag tag-danger">Fisik</span>
                    <h3 class="h5 fw-bold mb-2">Perundungan Fisik</h3>
                    <p class="text-muted mb-0" style="font-size: 0.9rem;">
                        Tindakan kekerasan fisik seperti memukul, mendorong, menendang, merusak barang milik orang lain, atau memalak paksa.
                    </p>
                </div>
            </div>

            <!-- Card 2: Bullying Verbal & Sosial -->
            <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                <div class="category-card h-100">
                    <div class="category-icon cat-warning">
                        <i class="fas fa-comments"></i>
                    </div>
                    <span class="category-tag tag-warning">Verbal &amp; Relasional</span>
                    <h3 class="h5 fw-bold mb-2">Verbal &amp; Emosional</h3>
                    <p class="text-muted mb-0" style="font-size: 0.9rem;">
                        Menghina fisik (body shaming), mengejek orang tua, menyebarkan rumor jahat, mengancam, atau mengucilkan dari pergaulan kelas.
                    </p>
                </div>
            </div>

            <!-- Card 3: Cyberbullying -->
            <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                <div class="category-card h-100">
                    <div class="category-icon cat-primary">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <span class="category-tag tag-primary">Daring / Sosmed</span>
                    <h3 class="h5 fw-bold mb-2">Cyberbullying</h3>
                    <p class="text-muted mb-0" style="font-size: 0.9rem;">
                        Teror di grup WhatsApp/sosial media, membuat akun palsu untuk mencemarkan nama baik, atau menyebarkan foto memalukan tanpa izin.
                    </p>
                </div>
            </div>

            <!-- Card 4: Fasilitas & Lainnya -->
            <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                <div class="category-card h-100">
                    <div class="category-icon cat-purple">
                        <i class="fas fa-school"></i>
                    </div>
                    <span class="category-tag tag-purple">Fasilitas &amp; Akademik</span>
                    <h3 class="h5 fw-bold mb-2">Fasilitas Sekolah</h3>
                    <p class="text-muted mb-0" style="font-size: 0.9rem;">
                        Vandalisme sarana sekolah, penyalahgunaan fasilitas kelas, maupun kecurangan dan pemerasan dalam kegiatan tugas akademik.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/landing/partials/categories.blade.php ENDPATH**/ ?>