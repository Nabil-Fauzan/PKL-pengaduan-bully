<?php $__env->startSection('title', 'Detail Pengaduan & Tanggapan'); ?>
<?php $__env->startSection('page_title', 'Detail Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Left Column: Complaint Details -->
    <div class="col-md-7">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-file-alt mr-1"></i>
                    Informasi Pengaduan
                </h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('dashboard.pengaduan')); ?>" class="btn btn-default btn-sm">
                        <i class="fas fa-arrow-left mr-1"></i> Kembali
                    </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Meta Info Table -->
                <table class="table table-bordered mb-4">
                    <tbody>
                        <tr>
                            <th style="width: 30%;">Siswa Pelapor</th>
                            <td>
                                <strong><?php echo e($pengaduan->siswa->nama ?? 'Siswa'); ?></strong>
                                <span class="text-muted ml-2">(NIS: <?php echo e($pengaduan->siswa->nis ?? '-'); ?>)</span>
                            </td>
                        </tr>
                        <tr>
                            <th>Kategori</th>
                            <td>
                                <?php if($pengaduan->kategori === 'bullying'): ?>
                                    <span class="badge bg-danger">Bullying</span>
                                <?php elseif($pengaduan->kategori === 'fasilitas'): ?>
                                    <span class="badge bg-info">Fasilitas</span>
                                <?php elseif($pengaduan->kategori === 'akademik'): ?>
                                    <span class="badge bg-primary">Akademik</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Lainnya</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Tanggal Masuk</th>
                            <td><?php echo e($pengaduan->tanggal_pengaduan->format('d F Y | H:i')); ?> WIB</td>
                        </tr>
                        <tr>
                            <th>Status Terkini</th>
                            <td>
                                <?php if($pengaduan->isTerabaikan()): ?>
                                    <span class="badge bg-danger">Terabaikan (>3 hari)</span>
                                <?php elseif($pengaduan->status === 'baru'): ?>
                                    <span class="badge bg-primary">Baru</span>
                                <?php elseif($pengaduan->status === 'diproses'): ?>
                                    <span class="badge bg-warning text-dark">Diproses</span>
                                <?php elseif($pengaduan->status === 'selesai'): ?>
                                    <span class="badge bg-success">Selesai</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Ditolak</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <h5 class="font-weight-bold mb-2">Judul Laporan:</h5>
                <p class="bg-light p-3 rounded border" style="font-size: 1.1rem; font-weight: 500;">
                    <?php echo e($pengaduan->judul); ?>

                </p>

                <h5 class="font-weight-bold mt-4 mb-2">Kronologi / Isi Laporan:</h5>
                <div class="bg-light p-3 rounded border" style="white-space: pre-wrap; line-height: 1.6;"><?php echo e($pengaduan->isi_pengaduan); ?></div>
            </div>
        </div>

        <!-- History of Counselor Responses -->
        <div class="card card-secondary card-outline mt-4">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-comments mr-1"></i>
                    Riwayat Tanggapan / Tindak Lanjut
                </h3>
            </div>
            <div class="card-body">
                <?php if($pengaduan->tanggapan->isEmpty()): ?>
                    <p class="text-muted text-center py-3 mb-0">Belum ada tindakan atau tanggapan tertulis untuk laporan ini.</p>
                <?php else: ?>
                    <div class="timeline timeline-inverse">
                        <?php $__currentLoopData = $pengaduan->tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanggapan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <i class="fas fa-comment bg-primary"></i>
                                <div class="timeline-item">
                                    <span class="time"><i class="far fa-clock"></i> <?php echo e($tanggapan->tanggal_tanggapan->format('d/m/Y H:i')); ?> WIB</span>
                                    <h3 class="timeline-header font-weight-bold text-primary d-flex align-items-center">
                                        <div class="rounded-circle text-white font-weight-bold d-inline-flex align-items-center justify-content-center mr-2 shrink-0" 
                                            style="width: 26px; height: 26px; background-color: #4f46e5; font-size: 10px;">
                                            <?php echo e(strtoupper(substr($tanggapan->petugas->nama ?? 'BK', 0, 2))); ?>

                                        </div>
                                        <span><?php echo e($tanggapan->petugas->nama ?? 'Petugas BK'); ?></span>
                                        <span class="text-muted font-weight-normal mx-1">menanggapi dengan status</span>
                                        <?php if($tanggapan->status_pengaduan === 'diproses'): ?>
                                            <span class="badge bg-warning text-dark">Diproses</span>
                                        <?php elseif($tanggapan->status_pengaduan === 'selesai'): ?>
                                            <span class="badge bg-success">Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </h3>
                                    <div class="timeline-body" style="white-space: pre-wrap;"><?php echo e($tanggapan->isi_tanggapan); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <i class="far fa-clock bg-gray"></i>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Right Column: Response Action Form -->
    <div class="col-md-5">
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-reply mr-1"></i>
                    Berikan Tanggapan & Tindak Lanjut
                </h3>
            </div>
            <div class="card-body">
                <?php if(session('success_message')): ?>
                    <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                        <i class="icon fas fa-check mr-2"></i> <?php echo e(session('success_message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                        <i class="icon fas fa-ban mr-2"></i> <strong>Ada kesalahan:</strong>
                        <ul class="mb-0 pl-3 mt-1 text-sm">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('petugas.pengaduan.tanggapan', $pengaduan->id_pengaduan)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <!-- Action Status -->
                    <div class="form-group">
                        <label for="status_pengaduan" class="font-weight-bold">Perbarui Status Laporan:</label>
                        <select name="status_pengaduan" id="status_pengaduan" class="form-control">
                            <option value="">-- Pilih Status Baru --</option>
                            <option value="diproses" <?php echo e(old('status_pengaduan', $pengaduan->status) === 'diproses' ? 'selected' : ''); ?>>Diproses (Sedang diselidiki)</option>
                            <option value="selesai" <?php echo e(old('status_pengaduan', $pengaduan->status) === 'selesai' ? 'selected' : ''); ?>>Selesai (Kasus ditutup)</option>
                            <option value="ditolak" <?php echo e(old('status_pengaduan', $pengaduan->status) === 'ditolak' ? 'selected' : ''); ?>>Ditolak (Iseng/Palsu)</option>
                        </select>
                        <small class="form-text text-muted">Mengubah status di sini akan mengubah status yang dilihat oleh siswa secara langsung.</small>
                    </div>

                    <!-- Tanggapan Textarea -->
                    <div class="form-group mt-4">
                        <label for="isi_tanggapan" class="font-weight-bold">Isi Tanggapan Resmi BK:</label>
                        <textarea name="isi_tanggapan" id="isi_tanggapan" rows="6" class="form-control" 
                            placeholder="Tuliskan keterangan tindakan, pemanggilan siswa, koordinasi dengan wali kelas, atau penyelesaian masalah secara rinci..."><?php echo e(old('isi_tanggapan')); ?></textarea>
                        <small class="form-text text-muted">Minimal menulis 5 karakter. Tanggapan Anda akan muncul di riwayat portal siswa pelapor secara transparan.</small>
                    </div>

                    <!-- Quick Response Templates -->
                    <div class="form-group mt-3">
                        <span class="text-xs font-weight-bold text-muted d-block mb-1"><i class="fas fa-magic mr-1"></i> Pilih Templat Tanggapan Cepat:</span>
                        <div class="d-flex flex-column gap-1">
                            <button type="button" class="btn btn-xs btn-outline-info text-left mb-1 quick-template-btn" 
                                data-text="Laporan Anda telah kami terima dan sedang dalam penyelidikan awal. Pihak BK akan segera memanggil pihak-pihak terkait untuk dimintai keterangan lebih lanjut." 
                                data-status="diproses">
                                <i class="fas fa-spinner mr-1"></i> <strong>Penyelidikan Awal</strong>: Laporan sedang diselidiki.
                            </button>
                            <button type="button" class="btn btn-xs btn-outline-success text-left mb-1 quick-template-btn" 
                                data-text="Masalah perundungan ini telah dimediasi oleh pihak BK. Seluruh pihak terkait telah dipanggil dan sepakat berdamai. Laporan dinyatakan selesai dan ditutup." 
                                data-status="selesai">
                                <i class="fas fa-check-circle mr-1"></i> <strong>Selesai & Damai</strong>: Pihak terkait dipanggil dan sepakat damai.
                            </button>
                            <button type="button" class="btn btn-xs btn-outline-danger text-left mb-1 quick-template-btn" 
                                data-text="Setelah dilakukan penelusuran lebih lanjut, laporan ini ditolak karena informasi yang diberikan kurang lengkap atau tidak ditemukan unsur perundungan di lapangan." 
                                data-status="ditolak">
                                <i class="fas fa-times-circle mr-1"></i> <strong>Tidak Cukup Bukti</strong>: Informasi kurang lengkap atau nihil bullying.
                            </button>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="mt-4 pt-3 border-top">
                        <button type="submit" class="btn btn-success btn-block font-weight-bold">
                            <i class="fas fa-paper-plane mr-1"></i> Kirim Tanggapan & Perbarui Laporan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const quickBtns = document.querySelectorAll('.quick-template-btn');
        const textarea = document.getElementById('isi_tanggapan');
        const statusSelect = document.getElementById('status_pengaduan');

        quickBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                textarea.value = this.getAttribute('data-text');
                const targetStatus = this.getAttribute('data-status');
                if (statusSelect) {
                    statusSelect.value = targetStatus;
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/petugas/detail_pengaduan.blade.php ENDPATH**/ ?>