<?php $__env->startSection('title', 'Pengaturan Jurusan'); ?>
<?php $__env->startSection('page_title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">

        <?php if(session('success_message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="icon fas fa-check mr-2"></i> <?php echo e(session('success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="icon fas fa-ban mr-2"></i> <strong>Ada kesalahan pengisian:</strong>
                <ul class="mb-0 mt-1 pl-3 text-sm">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="card card-primary card-outline mb-5">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-cogs mr-1"></i>
                    Pengaturan Pilihan Jurusan
                </h3>
            </div>
            
            <div class="card-body">
                <p class="text-muted">
                    Daftar di bawah ini menentukan pilihan jurusan yang akan muncul di dropdown formulir pendaftaran/edit akun siswa. Anda dapat menambah atau menghapus opsi jurusan secara dinamis.
                </p>
                <hr>

                <form action="<?php echo e(route('admin.setting.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div id="jurusan-container">
                        <label class="font-weight-bold mb-2">Daftar Jurusan Aktif:</label>
                        <?php $__currentLoopData = $list_jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="input-group mb-3 jurusan-row">
                                <input type="text" name="jurusan[]" value="<?php echo e($jurusan); ?>" 
                                    placeholder="Masukkan nama jurusan (contoh: Rekayasa Perangkat Lunak)..." 
                                    class="form-control" required>
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-danger remove-jurusan-btn" title="Hapus Jurusan ini">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Add Button -->
                    <div class="mb-4">
                        <button type="button" id="add-jurusan-btn" class="btn btn-success btn-sm font-weight-bold">
                            <i class="fas fa-plus mr-1"></i> Tambah Opsi Jurusan Baru
                        </button>
                    </div>

                    <!-- Form Actions -->
                    <div class="mt-4 pt-3 border-top d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary font-weight-bold">
                            <i class="fas fa-save mr-1"></i> Simpan Semua Perubahan
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<!-- Template Row for Dynamic JS Add -->
<template id="jurusan-row-template">
    <div class="input-group mb-3 jurusan-row">
        <input type="text" name="jurusan[]" placeholder="Masukkan nama jurusan (contoh: Animasi)..." 
            class="form-control" required>
        <div class="input-group-append">
            <button type="button" class="btn btn-danger remove-jurusan-btn" title="Hapus Jurusan ini">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
    </div>
</template>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const container = document.getElementById('jurusan-container');
        const addButton = document.getElementById('add-jurusan-btn');
        const template = document.getElementById('jurusan-row-template');

        // Add major row
        addButton.addEventListener('click', function() {
            const clone = template.content.cloneNode(true);
            container.appendChild(clone);
        });

        // Remove major row (delegate event to container)
        container.addEventListener('click', function(e) {
            const removeBtn = e.target.closest('.remove-jurusan-btn');
            if (removeBtn) {
                const row = removeBtn.closest('.jurusan-row');
                const totalRows = container.querySelectorAll('.jurusan-row').length;
                if (totalRows > 1) {
                    row.remove();
                } else {
                    alert('Minimal harus ada 1 pilihan jurusan aktif.');
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/admin/setting.blade.php ENDPATH**/ ?>