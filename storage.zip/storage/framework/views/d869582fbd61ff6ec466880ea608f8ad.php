<?php $__env->startSection('title', 'Data Petugas / Admin'); ?>
<?php $__env->startSection('page_title', 'Data Petugas & Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">

        <!-- Action & Search Card -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <a href="<?php echo e(route('admin.petugas.tambah')); ?>" class="btn btn-primary btn-sm font-weight-bold">
                            <i class="fas fa-plus mr-1"></i> Tambah Petugas/Admin Baru
                        </a>
                    </div>
                    <div class="col-md-6">
                        <form action="<?php echo e(route('admin.petugas')); ?>" method="GET" class="float-md-right w-100" style="max-width: 350px;">
                            <div class="input-group input-group-sm">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                                    placeholder="Cari nama, username, atau email..." class="form-control">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary font-weight-bold">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <?php if(request()->filled('search')): ?>
                                        <a href="<?php echo e(route('admin.petugas')); ?>" class="btn btn-default" title="Reset Pencarian">
                                            <i class="fas fa-sync-alt"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <?php if(session('success_message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="icon fas fa-check mr-2"></i> <?php echo e(session('success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="icon fas fa-ban mr-2"></i> <?php echo e(session('error_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <!-- List Card -->
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title font-weight-bold">
                    <i class="fas fa-user-tie mr-1"></i>
                    Daftar Akun Petugas & Admin
                </h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-striped mb-0">
                        <thead>
                            <tr>
                                <th style="width: 60px;" class="text-center">No</th>
                                <th>Nama Lengkap</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th style="width: 120px;">Role</th>
                                <th style="width: 120px;">Status</th>
                                <th style="width: 220px;" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = ($data_petugas->currentPage() - 1) * $data_petugas->perPage() + 1;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $data_petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center font-weight-bold"><?php echo e($no++); ?></td>
                                    <td class="font-weight-bold">
                                        <?php echo e($petugas->nama); ?>

                                        <?php if($petugas->id_user === Auth::guard('web')->id()): ?>
                                            <span class="badge bg-indigo text-white ml-1">Saya</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($petugas->username); ?></td>
                                    <td><?php echo e($petugas->email); ?></td>
                                    <td>
                                        <?php if($petugas->role === 'admin'): ?>
                                            <span class="badge bg-danger">Administrator</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Petugas BK</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($petugas->status === 'aktif'): ?>
                                            <span class="badge bg-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Nonaktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-inline-flex align-items-center gap-1">
                                            <a href="<?php echo e(route('admin.petugas.edit', $petugas->id_user)); ?>" class="btn btn-success btn-xs font-weight-bold mr-1">
                                                <i class="fas fa-edit mr-1"></i> Ubah
                                            </a>
                                            
                                            <?php if($petugas->id_user !== Auth::guard('web')->id()): ?>
                                                <form action="<?php echo e(route('admin.petugas.toggle', $petugas->id_user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Apakah Anda yakin ingin mengubah status aktif petugas ini?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php if($petugas->status === 'aktif'): ?>
                                                        <button type="submit" class="btn btn-danger btn-xs font-weight-bold">
                                                            <i class="fas fa-ban mr-1"></i> Nonaktifkan
                                                        </button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-primary btn-xs font-weight-bold">
                                                            <i class="fas fa-check mr-1"></i> Aktifkan
                                                        </button>
                                                    <?php endif; ?>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-secondary btn-xs font-weight-bold" disabled title="Tidak bisa menonaktifkan akun sendiri">
                                                    <i class="fas fa-ban mr-1"></i> Nonaktifkan
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">Tidak ada data petugas/admin ditemukan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if($data_petugas->hasPages()): ?>
                <div class="card-footer clearfix d-flex justify-content-end">
                    <?php echo e($data_petugas->links('pagination::bootstrap-4')); ?>

                </div>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/admin/petugas/index.blade.php ENDPATH**/ ?>