<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Riwayat Pengaduan Saya</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-slate-50 text-slate-900 min-h-screen p-4 sm:p-6 md:p-8 flex items-center justify-center">

    <div class="max-w-4xl w-full bg-white border border-slate-200 rounded-xl shadow-sm p-6 sm:p-8">
        
        <!-- Header -->
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">Riwayat Pengaduan Saya</h1>
                <p class="text-sm text-slate-500 mt-1">Daftar laporan pengaduan yang telah Anda kirimkan</p>
            </div>
            <div class="flex gap-3 w-full sm:w-auto">
                <a href="<?php echo e(route('dashboard.pengaduan.tambah')); ?>" class="w-full sm:w-auto text-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors cursor-pointer">
                    Tulis Pengaduan Baru
                </a>
            </div>
        </div>

        <!-- Success Alert -->
        <?php if(session('success_message')): ?>
            <div class="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-lg p-4 mb-6 text-sm font-medium flex items-center gap-3">
                <svg class="h-5 w-5 text-emerald-600 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span><?php echo e(session('success_message')); ?></span>
            </div>
        <?php endif; ?>

        <!-- Complaint Table / List -->
        <?php if($data_pengaduan->isEmpty()): ?>
            <!-- Empty State -->
            <div class="border border-dashed border-slate-200 rounded-xl p-12 text-center">
                <svg class="mx-auto h-12 w-12 text-slate-300 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
                <h3 class="text-sm font-semibold text-slate-900 mb-1">Belum Ada Pengaduan</h3>
                <p class="text-xs text-slate-500 mb-6">Anda belum pernah mengirimkan laporan pengaduan apapun.</p>
                <a href="<?php echo e(route('dashboard.pengaduan.tambah')); ?>" class="inline-flex items-center px-4 py-2 border border-transparent text-xs font-semibold rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm cursor-pointer">
                    Kirim Laporan Pertama Anda
                </a>
            </div>
        <?php else: ?>
            <!-- Table View (Hidden on mobile) -->
            <div class="hidden sm:block overflow-x-auto border border-slate-200 rounded-xl">
                <table class="w-full text-left border-collapse text-sm">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold">
                            <th class="py-3 px-4 w-12 text-center">No</th>
                            <th class="py-3 px-4">Judul Laporan</th>
                            <th class="py-3 px-4 w-32">Kategori</th>
                            <th class="py-3 px-4 w-40">Tanggal</th>
                            <th class="py-3 px-4 w-28 text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-200">
                        <?php $__currentLoopData = $data_pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pengaduan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-slate-50/50 transition-colors text-slate-600">
                                <td class="py-3 px-4 text-center font-medium"><?php echo e($key + 1); ?></td>
                                <td class="py-3 px-4 font-semibold text-slate-950 truncate max-w-xs"><?php echo e($pengaduan->judul); ?></td>
                                <td class="py-3 px-4">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200">
                                        <?php echo e(ucfirst($pengaduan->kategori)); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-4 text-xs"><?php echo e($pengaduan->tanggal_pengaduan->format('d/m/Y | H:i')); ?></td>
                                <td class="py-3 px-4 text-center">
                                    <?php if($pengaduan->status === 'baru'): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-100">Baru</span>
                                    <?php elseif($pengaduan->status === 'diproses'): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-100">Diproses</span>
                                    <?php elseif($pengaduan->status === 'selesai'): ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">Selesai</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-100">Ditolak</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- List View (Only visible on mobile) -->
            <div class="block sm:hidden space-y-4">
                <?php $__currentLoopData = $data_pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengaduan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-slate-200 rounded-xl p-4 bg-white hover:border-indigo-100 transition-all">
                        <div class="flex justify-between items-start mb-2">
                            <span class="text-xs font-semibold text-slate-400"><?php echo e($pengaduan->tanggal_pengaduan->format('d/m/Y')); ?></span>
                            <?php if($pengaduan->status === 'baru'): ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-100">Baru</span>
                            <?php elseif($pengaduan->status === 'diproses'): ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-100">Diproses</span>
                            <?php elseif($pengaduan->status === 'selesai'): ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">Selesai</span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-50 text-red-700 border border-red-100">Ditolak</span>
                            <?php endif; ?>
                        </div>
                        <h4 class="font-bold text-slate-900 mb-1"><?php echo e($pengaduan->judul); ?></h4>
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-800 border border-slate-200 mb-2">
                            <?php echo e(ucfirst($pengaduan->kategori)); ?>

                        </span>
                        <p class="text-xs text-slate-500 line-clamp-2"><?php echo e($pengaduan->isi_pengaduan); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <!-- Footer Actions -->
        <div class="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-semibold text-slate-500">
            <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-indigo-600 transition-colors">
                &larr; Kembali ke Dashboard
            </a>
            
            <a href="#" onclick="event.preventDefault(); if(confirm('Yakin ingin keluar?')) document.getElementById('logout-form').submit();" 
                class="text-red-500 hover:text-red-700 transition-colors">
                Keluar (Logout)
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pkl-bully\resources\views/siswa/pengaduan.blade.php ENDPATH**/ ?>